﻿using LibraryManagement.Data.Models;
using LibraryManagement.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Net;
using System.Net.Http.Headers;

namespace LibraryManagement.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly string _baseUri = "https://api.stackexchange.com/2.2";
        private LibraryContext _context;
        public HomeController(ILogger<HomeController> logger, LibraryContext context)
        {
            _logger = logger;
            _context = context; 
        }

        public IActionResult Index()
        {
            var list = GetBooks(null, null);
            return View();
        }
        [Route("api/GetAllBooks")]
        public async Task<ActionResult> GetAllBooks()
        {
            try
            {
                var books = await _context.Books.ToListAsync();
                return Ok(books);
            }catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        private List<Book> GetBooks(int? categoryID, int? subCategoryId)
        {
            string query = "EXEC [dbo].[GetAllBooks] " +
                "@CategoryId," +
                "@SubCategoryId";

            query = query.Replace("@CategoryId", categoryID != null ? categoryID.ToString():"");
            query = query.Replace("@SubCategoryId", subCategoryId != null ? subCategoryId.ToString() : "");

            var result = _context.Database.SqlQuery<Book>(query);

            var n = result.ToList();
            return null;
        }
        public IActionResult GetStackOverflow()
        {
            List<StackResponseWrapper> questions = null;

            HttpClientHandler handler = new HttpClientHandler();
            handler.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
            using (var Client = new HttpClient(handler))
            {
                Client.BaseAddress = new Uri(_baseUri);
                //HTTP GET
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var response = Client.GetAsync("2.2/questions?site=stackoverflow");
                response.Wait();
                var result = response.Result;

                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadFromJsonAsync<List<StackResponseWrapper>>();
                    readTask.Wait();
                    questions = readTask.Result;
                    ViewData["Questions"] = questions;
                }

            }
            return View("Privacy");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
    public class StackResponseWrapper
    {
        public List<question> items { get; set; }
        public bool has_more { get; set; }
        public int quota_max { get; set; }
        public int quota_remaining { get; set; }
    }
    public class question
    {
        public List<string> tags { get; set; }
        public string link { get; set; }
        public owner owner { get; set; }
        public bool is_answered { get; set; }
        public long view_count { get; set; }
        public string last_activity_date { get; set; }
        public long score { get; set; }
        public long answer_count { get; set; }
        public string creation_date { get; set; }
        public string question_id { get; set; }
        public string title { get; set; }
    }
    public class owner
    {
        public string user_id { get; set; }
        public string reputation { get; set; }
        public string user_type { get; set; }
        public string profile_image { get; set; }
        public string display_name { get; set; }
        public string link { get; set; }

    }
}