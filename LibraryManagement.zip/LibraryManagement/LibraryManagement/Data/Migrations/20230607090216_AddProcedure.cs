﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LibraryManagement.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddProcedure : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var sp = @"
							CREATE PROCEDURE [dbo].[GetAllBooks]
								@CategoryId int = null,
								@SubCategoryId int = null
							AS
							BEGIN
								SELECT b.* FROM [dbo].[Books] b
								LEFT OUTER JOIN [dbo].[SubCategories] s ON s.Id = b.SubCategoryId 
								LEFT OUTER JOIN [dbo].[Categories] r ON r.Id = b.CategoryId
								WHERE 
								 ( ISNULL(@CategoryId,'') = '' OR b.CategoryId = @CategoryId ) 
								AND ( ISNULL(@SubCategoryId,'') = '' OR b.SubCategoryId = @SubCategoryId) 
							END
							GO
            ";

            migrationBuilder.Sql(sp);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
