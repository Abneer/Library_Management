﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace LibraryManagement.Data.Migrations
{
    /// <inheritdoc />
    public partial class SeedDataInit : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_SubCategories",
                table: "SubCategories");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Categories",
                table: "Categories");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Books",
                table: "Books");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Authors",
                table: "Authors");

            migrationBuilder.RenameTable(
                name: "SubCategories",
                newName: "SubCategory");

            migrationBuilder.RenameTable(
                name: "Categories",
                newName: "Category");

            migrationBuilder.RenameTable(
                name: "Books",
                newName: "Book");

            migrationBuilder.RenameTable(
                name: "Authors",
                newName: "Author");

            migrationBuilder.AddPrimaryKey(
                name: "PK_SubCategory",
                table: "SubCategory",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Category",
                table: "Category",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Book",
                table: "Book",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Author",
                table: "Author",
                column: "Id");

            migrationBuilder.InsertData(
                table: "Author",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 1, "Lisa Aan" },
                    { 2, "PeterSon" },
                    { 3, "Henry K." }
                });

            migrationBuilder.InsertData(
                table: "Book",
                columns: new[] { "Id", "AuthorId", "CategoryId", "CreatedBy", "CreatedOn", "Description", "PrintedOn", "SubCategoryId", "Title" },
                values: new object[,]
                {
                    { 1, 3, 1, "Myth", new DateTime(2023, 6, 7, 13, 30, 9, 350, DateTimeKind.Local).AddTicks(1182), "Hub-e-Watan", new DateTime(2023, 6, 7, 13, 30, 9, 350, DateTimeKind.Local).AddTicks(1183), 2, "Hub-e-Watan" },
                    { 2, 3, 2, "Myth", new DateTime(2023, 6, 7, 13, 30, 9, 350, DateTimeKind.Local).AddTicks(1184), "Study of Stars", new DateTime(2023, 6, 7, 13, 30, 9, 350, DateTimeKind.Local).AddTicks(1184), 3, "Study of Stars" },
                    { 3, 2, 2, "Myth", new DateTime(2023, 6, 7, 13, 30, 9, 350, DateTimeKind.Local).AddTicks(1185), "Daily Life Mechanics", new DateTime(2023, 6, 7, 13, 30, 9, 350, DateTimeKind.Local).AddTicks(1185), 4, "Daily Life Mechanics" },
                    { 4, 2, 3, "Myth", new DateTime(2023, 6, 7, 13, 30, 9, 350, DateTimeKind.Local).AddTicks(1186), "Learn English in 30 Days", new DateTime(2023, 6, 7, 13, 30, 9, 350, DateTimeKind.Local).AddTicks(1187), 5, "Learn English in 30 Days" },
                    { 5, 1, 3, "Myth", new DateTime(2023, 6, 7, 13, 30, 9, 350, DateTimeKind.Local).AddTicks(1188), "Learn Arabic in 30 Days", new DateTime(2023, 6, 7, 13, 30, 9, 350, DateTimeKind.Local).AddTicks(1188), 6, "Learn Arabic in 30 Days" },
                    { 6, 1, 1, "Myth", new DateTime(2023, 6, 7, 13, 30, 9, 350, DateTimeKind.Local).AddTicks(1173), "Amanda Maeir", new DateTime(2023, 6, 7, 13, 30, 9, 350, DateTimeKind.Local).AddTicks(1180), 1, "Amanda Maeir" }
                });

            migrationBuilder.InsertData(
                table: "Category",
                columns: new[] { "Id", "Title" },
                values: new object[,]
                {
                    { 1, "Literature" },
                    { 2, "Science" },
                    { 3, "Language" }
                });

            migrationBuilder.InsertData(
                table: "SubCategory",
                columns: new[] { "Id", "CategoryId", "Title" },
                values: new object[,]
                {
                    { 1, 1, "Novel" },
                    { 2, 1, "Poetry" },
                    { 3, 2, "Astrology" },
                    { 4, 2, "Physics" },
                    { 5, 3, "Engish" },
                    { 6, 3, "Arabic" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_SubCategory",
                table: "SubCategory");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Category",
                table: "Category");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Book",
                table: "Book");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Author",
                table: "Author");

            migrationBuilder.DeleteData(
                table: "Author",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Author",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Author",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Category",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Category",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Category",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "SubCategory",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "SubCategory",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "SubCategory",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "SubCategory",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "SubCategory",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "SubCategory",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.RenameTable(
                name: "SubCategory",
                newName: "SubCategories");

            migrationBuilder.RenameTable(
                name: "Category",
                newName: "Categories");

            migrationBuilder.RenameTable(
                name: "Book",
                newName: "Books");

            migrationBuilder.RenameTable(
                name: "Author",
                newName: "Authors");

            migrationBuilder.AddPrimaryKey(
                name: "PK_SubCategories",
                table: "SubCategories",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Categories",
                table: "Categories",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Books",
                table: "Books",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Authors",
                table: "Authors",
                column: "Id");
        }
    }
}
