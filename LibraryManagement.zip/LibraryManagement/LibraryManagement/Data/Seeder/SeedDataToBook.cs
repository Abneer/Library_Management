﻿using LibraryManagement.Data.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagement.Data.Seeder
{
    public class SeedDataToBook : IEntityTypeConfiguration<Book>
    {
        public void Configure(EntityTypeBuilder<Book> builder)
        {
            builder.ToTable("Book");
            builder.HasData
                            (
                                new Book
                                {
                                    Id = 6,
                                    CategoryId = 1,
                                    SubCategoryId = 1,
                                    Title = "Amanda Maeir",
                                    Description = "Amanda Maeir",
                                    AuthorId = 1,
                                    CreatedBy="Myth",
                                    CreatedOn = DateTime.Now,
                                    PrintedOn = DateTime.Now
                                },
                                new Book
                                {
                                    Id = 1,
                                    CategoryId = 1,
                                    SubCategoryId = 2,
                                    Title = "Hub-e-Watan",
                                    Description = "Hub-e-Watan",
                                    AuthorId = 3,
                                    CreatedBy="Myth",
                                    CreatedOn = DateTime.Now,
                                    PrintedOn = DateTime.Now
                                },
                                new Book
                                {
                                    Id = 2,
                                    CategoryId = 2,
                                    SubCategoryId = 3,
                                    Title = "Study of Stars",
                                    Description = "Study of Stars",
                                    AuthorId = 3,
                                    CreatedBy="Myth",
                                    CreatedOn = DateTime.Now,
                                    PrintedOn = DateTime.Now
                                },
                                new Book
                                {
                                    Id = 3,
                                    CategoryId = 2,
                                    SubCategoryId = 4,
                                    Title = "Daily Life Mechanics",
                                    Description = "Daily Life Mechanics",
                                    AuthorId = 2,
                                    CreatedBy="Myth",
                                    CreatedOn = DateTime.Now,
                                    PrintedOn = DateTime.Now
                                },
                                new Book
                                {
                                    Id = 4,
                                    CategoryId = 3,
                                    SubCategoryId = 5,
                                    Title = "Learn English in 30 Days",
                                    Description = "Learn English in 30 Days",
                                    AuthorId = 2,
                                    CreatedBy="Myth",
                                    CreatedOn = DateTime.Now,
                                    PrintedOn = DateTime.Now
                                },
                                new Book
                                {
                                    Id = 5,
                                    CategoryId = 3,
                                    SubCategoryId = 6,
                                    Title = "Learn Arabic in 30 Days",
                                    Description = "Learn Arabic in 30 Days",
                                    AuthorId = 1,
                                    CreatedBy="Myth",
                                    CreatedOn = DateTime.Now,
                                    PrintedOn = DateTime.Now
                                }
                            );

        }
    }
}
