﻿using LibraryManagement.Data.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

public class SeedDataToCategory : IEntityTypeConfiguration<Category>
{
    public void Configure(EntityTypeBuilder<Category> builder)
    {
        builder.ToTable("Category");
        builder.HasData
                        (
                            new Category
                            {
                                Id = 1,
                                Title = "Literature",
                            },
                            new Category
                            {
                                Id = 2,
                                Title = "Science",
                            },
                            new Category
                            {
                                Id = 3,
                                Title = "Language",
                            }
                        );

    }
}