﻿using LibraryManagement.Data.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

public class SeedDataToSubCategory : IEntityTypeConfiguration<SubCategory>
{
    public void Configure(EntityTypeBuilder<SubCategory> builder)
    {
        builder.ToTable("SubCategory");
        builder.HasData
                        (
                            new SubCategory
                            {
                                CategoryId = 1,
                                Id = 1,
                                Title = "Novel",
                            },
                            new SubCategory
                            {
                                CategoryId = 1,
                                Id = 2,
                                Title = "Poetry",
                            },
                            new SubCategory
                            {
                                CategoryId = 2,
                                Id = 3,
                                Title = "Astrology",
                            },
                            new SubCategory
                            {
                                CategoryId = 2,
                                Id = 4,
                                Title = "Physics",
                            },
                            new SubCategory
                            {
                                CategoryId = 3,
                                Id = 5,
                                Title = "Engish",
                            },
                            new SubCategory
                            {
                                CategoryId = 3,
                                Id = 6,
                                Title = "Arabic",
                            }
                        );

    }
}