﻿using LibraryManagement.Data.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagement.Data.Seeder
{
    public class SeedDataToAuthor : IEntityTypeConfiguration<Author>
    {
        public void Configure(EntityTypeBuilder<Author> builder)
        {
            builder.ToTable("Author");
            builder.HasData
                            (
                                new Author
                                {
                                    Id = 1,
                                    Name = "Lisa Aan",
                                },
                                new Author
                                {
                                    Id = 2,
                                    Name = "PeterSon",
                                },
                                new Author
                                {
                                    Id = 3,
                                    Name = "Henry K.",
                                }
                            );

        }
    }
}
