﻿using LibraryManagement.Data.Seeder;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagement.Data.Models
{
    public class LibraryContext: DbContext
    {
        public LibraryContext(DbContextOptions<LibraryContext> options) : base(options)
        {
        }
       

        public DbSet<Book> Books { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<SubCategory> SubCategories { get; set; }
        public DbSet<Author> Authors { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new SeedDataToCategory());
            modelBuilder.ApplyConfiguration(new SeedDataToSubCategory());
            modelBuilder.ApplyConfiguration(new SeedDataToAuthor());
            modelBuilder.ApplyConfiguration(new SeedDataToBook());
            base.OnModelCreating(modelBuilder);
        }
    }
}
